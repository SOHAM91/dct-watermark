//�{���W�١Gembed.java
//�{���\��G�äJ�B���L�{��
//����d�ҡGjava embed

import java.io.*;
import java.util.*;
//import DCT;
//import DCT2;
//import Qt;
//import zigZag;
public class embed
 {
   public static void main(String args[]) throws IOException
        {
      // Ū��Lena.raw��
      FileInputStream fis = new FileInputStream("lena.raw");
      InputStream is = new BufferedInputStream(fis, 1024);
      DataInputStream dis = new DataInputStream(is);

       // Ū��watermark��
      FileInputStream fis1 = new FileInputStream("ccu.raw");
      InputStream is1 = new BufferedInputStream(fis1, 1024);
      DataInputStream dis1 = new DataInputStream(is1);




      // DCT �ഫ���X��
      FileOutputStream fos1=new FileOutputStream("lena1.raw");
      OutputStream os1=new BufferedOutputStream(fos1, 1024);
      DataOutputStream dos1= new DataOutputStream(os1);

       // IDCT �ഫ���X��
      FileOutputStream fos2=new FileOutputStream("lena2.raw");
      OutputStream os2=new BufferedOutputStream(fos2, 1024);
      DataOutputStream dos2= new DataOutputStream(os2);

          // original image process
          int N=8;
          int buff1[][] = new int[512][512];       //Original image
          int buff2[][] = new int[512][512];      //DCT Original imgage coefficients
          int buff3[][] = new int[512][512];      //IDCT Original image coefficients

          int b1[][] = new int[N][N];                 //DCT input
          int b2[][] = new int[N][N];                 //DCT output

          int b3[][] = new int[N][N];                 //IDCT input
          int b4[][] = new int[N][N];                //IDCT output

          // Watermark image process
          int W=4;
          int water1[][] = new int[128][128];     //Watermark image
          int water2[][] = new int[128][128];    //Random Watermark image
          int water3[][] = new int[128][128]; //DCT Watermark imgage coefficients

          int w1[][] = new int[W][W]; 	            //DCT input
          int w2[][] = new int[W][W]; 	           //DCT output
          int w3[][] = new int[W][W]; 	           //Quantization output
          int mfbuff1[][]=new int[128][128];     // Embed coefficients
          int mfbuff2[] = new int[128*128];      // 2 to 1

          //Random process
          int a,b,c;
          int tmp[]=new int [128*128];

          //Random embed
          int c1;
          int cc=0;
          int tmp1[]=new int [128*128];

          //divide 8*8 block
          int k=0,l=0;

          // �N lena.raw Ū�J buff1[512][512] ��
          for(int i=0;i<512;i++) {
            for(int j=0;j<512;j++) {
                  buff1[i][j]=dis.readByte();
                  if(buff1[i][j]<0)
                    buff1[i][j]=128+127-(-(buff1[i][j])-1);      //�ഫ�� 0 ~ 255
            }
      }

      // �N Watermark Ū�J Water1[128][128] ��
          for(int i=0;i<128;i++) {
            for(int j=0;j<128;j++) {
                  water1[i][j]=dis1.readByte();
                  if(water1[i][j]<0)
                    water1[i][j]=128+127-(-(water1[i][j])-1);       //�ഫ�� 0 ~ 255
            }
      }

      //�N Original image ���� 8*8 �� block �@ DCT �ഫ
          Date T=new Date();                                                      //�ŧi Date ����
          long time1 =T.getTime();                                             //�O���}�l�ɶ�
          System.out.println("Original image         ---> FDCT");

          for(int y=0;y<512;y+=N) {
            for(int x=0;x<512;x+=N) {
              for(int i=y;i<y+N;i++) {
               for(int j=x;j<x+N;j++) {
                     b1[k][l]=buff1[i][j];
                           l++;
                   }
                   l=0;
                   k++;
             }
             k=0;
             DCT o1= new DCT();            //�ŧi DCT ����
             o1.ForwardDCT(b1,b2);        //�ޥ� DCT class ��,ForwardDCT����k

             for (int p=y;p<y+N;p++) {
               for (int q=x;q<x+N;q++ ) {
                 buff2[p][q]=b2[k][l];
                 l++;
               }
               l=0;
               k++;
             }
             k=0;

            }
      }
      System.out.println("                       OK!      ");



      // Watermark image �@ Random �B�z
      System.out.println("Watermark image        ---> Random");
      Random r =new Random(19);                //�]�w�üƲ��;���seed
      for (int i = 0 ; i < 128 ; i++ ) {
            for ( int j = 0 ; j < 128 ; j++ ) {
              while(true){
                c=r.nextInt(128*128);
                if (tmp[c]==0)
                  break;
              }
                     a=(c/128);
              b=(c%128);
              water2[i][j]=water1[a][b];
              tmp[c]=1;
        }
      }
      System.out.println("                       OK!      ");

      //�N Watermark image ���� 4*4 �� block �@ DCT �ഫ�PQuantization
      k=0;l=0;
      System.out.println("Watermark image        ---> FDCT & Quantization");
       for(int y=0;y<128;y+=W) {
            for(int x=0;x<128;x+=W) {
          for(int i=y;i<y+W;i++) {
               for(int j=x;j<x+W;j++) {
                     w1[k][l]=water2[i][j];
             l++;
                   }
                   l=0;
                   k++;
             }
             k=0;

        //�ŧi DCT2 ����
             DCT2 wm1= new DCT2();

        //�ޥ�DCT2 class ��,ForwardDCT����k
             wm1.ForwardDCT(w1,w2);

                 Qt qw1=new Qt();        	         //�ŧi Qt ����
                 qw1.WaterQt(w2,w3);          //�ޥ�Qt class ��,WaterQt����k

                 for (int p=y;p<y+W;p++) {
               for (int q=x;q<x+W;q++ ) {
             water3[p][q]=w3[k][l];
                 l++;
                   }
               l=0;
                   k++;
             }
             k=0;
            }
     }
     System.out.println("                       OK!      ");

         //Embedding Watermark  water3[128][128] -->buff2[512][512]
     System.out.println("Watermarked image      ---> Embedding");

          //Random Embedding
      Random r1 =new Random(24);        //�]�w�üƲ��;���seed
      for (int i = 0 ; i < 128 ; i++ ) {
            for ( int j = 0 ; j < 128 ; j++ ) {
              while(true){
                c1=r1.nextInt(128*128);
                if (tmp1[c1]==0)
                  break;
              }
                     a=(c1/128);
              b=(c1%128);
                  mfbuff1[i][j]=water3[a][b];
          tmp1[c1]=1;
         }
       }

      //  �G�� �� �@��
      zigZag scan= new zigZag();
          scan.two2one(mfbuff1,mfbuff2);





          // WriteBack coefficients
          for(int i=0;i<512;i+=N) {
            for(int j=0;j<512;j+=N) {
                 buff2[i+1][j+4]=mfbuff2[cc];
                 cc++;
         buff2[i+2][j+3]=mfbuff2[cc];
                 cc++;
                 buff2[i+3][j+2]=mfbuff2[cc];
                 cc++;
                 buff2[i+4][j+1]=mfbuff2[cc];
                 cc++;
        }
          } cc=0;
      System.out.println("                       OK!      ");

          // �N Watermarked image ���� 8*8 �� block �@ IDCT �ഫ
      System.out.println("Watermarked image      ---> IDCT");
      k=0;l=0;
          for(int y=0;y<512;y+=N) {
            for(int x=0;x<512;x+=N) {
             for(int i=y;i<y+N;i++) {
               for(int j=x;j<x+N;j++) {
                     b3[k][l]=buff2[i][j];
             l++;
                   }
                   l=0;
                   k++;
             }
             k=0;

             DCT o2= new DCT();     //�ŧi DCT ����
             o2.InverseDCT(b3,b4);  //�ޥ�DCT class ��,InverseDCT����k

             for (int p=y;p<y+N;p++) {
               for (int q=x;q<x+N;q++ ) {
             buff3[p][q]=b4[k][l];
                 l++;
                   }
               l=0;
                   k++;
             }
             k=0;
            }
      }
          System.out.println("                       OK!      ");


            // �g�J�ɮ� lena1.raw
          for (int i=0;i<512;i++){
        for(int j=0;j<512;j++)
              dos1.writeByte(buff2[i][j]);
          }
          dos1.close();

          // �g�J�ɮ� lena2.raw
          for (int i=0;i<512;i++){
        for(int j=0;j<512;j++)
                    dos2.writeByte(buff3[i][j]);
          }
      dos2.close();

           Date T2=new Date();                           //�ŧi Date ����
          long time2 =T2.getTime();                 //�O�������ɶ�
          System.out.println("Total time : "+((time2-time1)/360)+" Sec");
    }
 }
