//�{���W�١GzigZag.java
//�{���\��GzigZag ���O,�ttwo2one(�G����@��)�Pone2two
//(�@����G��)���zigzag scan��k

class zigZag
{
  static int N = 128;

  zigZag(){

  }  // Constructor

  void two2one(int input[][], int output[] ){
        int n=0,x=0,y=0;
        output[n]=input[x][y];
        n++;
        while(true){

        if ((x == 0) && (y <= (N-2)))
         {
       y++;
           output[n]=input[x][y];
           n++;
           while(true){
                x++;y--;
            output[n]=input[x][y];
            n++;
                     if ((y == 0))
                 break;
            }
         }

        if ((y == 0) && (x <= (N-2)))
         {
   x++;
           output[n]=input[x][y];
           n++;
           while(true){
               x--;y++;
            output[n]=input[x][y];
            n++;
                if ((x == 0))
                 break;
            }
         }

        if ((x == (N-1)) && (y < (N-2)))
         {
               y++;
           output[n]=input[x][y];
           n++;
           while(true){
        x--;y++;
            output[n]=input[x][y];
            n++;
                if ((y == (N-1)))
                 break;
            }
         }

        if ((y == (N-1)) && (x < (N-2)))
         {
   x++;
           output[n]=input[x][y];
           n++;
           while(true){
                x++;y--;
            output[n]=input[x][y];
            n++;

                if ((x == (N-1)))
                 break;
            }
         }

        if ((x==(N-1)) && (y==(N-2))){
         y++;
         output[n]=input[x][y];
         break;
        }

        }//while
 }// 2 Dimension --> 1 Dimension

  void one2two(int input[],int output[][] ){
    int n=0,x=0,y=0;
output[x][y]=input[n];
n++;
        while(true){
        if ((x == 0) && (y <= (N-2)))
         {
       y++;
           output[x][y]=input[n];
           n++;
           while(true){
               x++;y--;
            output[x][y]=input[n];
            n++;

                if ((y == 0))
                 break;
            }
         }

             if ((y == 0) && (x <= (N-2)))
         {
               x++;
           output[x][y]=input[n];
           n++;
           while(true){
    x--;y++;
            output[x][y]=input[n];
            n++;

                if ((x == 0))
                 break;
            }
         }




        if ((x == (N-1)) && (y < (N-2)))
         {
       y++;
           output[x][y]=input[n];
           n++;
           while(true){
                x--;y++;
            output[x][y]=input[n];
            n++;

                if ((y == (N-1)))
                 break;
            }
         }

        if ((y == (N-1)) && (x < (N-2)))
         {
       x++;
           output[x][y]=input[n];
           n++;
           while(true){
                x++;y--;
            output[x][y]=input[n];
            n++;


                if ((x == (N-1)))
                 break;
            }
         }

        if ((x==(N-1)) && (y==(N-2))){
         y++;
         output[x][y]=input[n];
         break;
        }

        }//while

  }// 1 Dimension --> 2 Dimension
}

