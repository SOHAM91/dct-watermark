//�{���W�١GQt.java
//�{���\��G Qt ���O,�tWaterQt(�q��)�PWaterDeQt(�϶q��)��ؤ�k

class Qt
{
    static int N = 4;
    public double Qtable[][]  = {{20,30, 30, 35},{30,30, 35, 45},
                                             {30,35, 45, 50},{35,45, 50, 60}};

    public double filter[][]  = {{0.2,0.6,0.6, 1}, {0.6,0.6, 1,1.1},
                                 {0.6,1, 1.1,1.2}, {1,1.1, 1.2,1.3}};
Qt(){}

// Quantization

void WaterQt(int input[][], int output[][] )
 {
  for (int i=0;i<N ;i++ ){
   for (int j=0;j<N ;j++ )
    output[i][j]=(int) Math.round((input[i][j])/ ((Qtable[i][j])*(filter[i][j])));
   }
 }

//De Quantization

void WaterDeQt(int input[][],int output[][] )
 {
  for (int i=0;i<N ;i++ ){
   for (int j=0;j<N ;j++ )
     output[i][j]=(int)((input[i][j])* ((Qtable[i][j])*(filter[i][j])));
  }
 }
}
